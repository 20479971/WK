-- Base de Dados
CREATE DATABASE "WK"
WITH 
OWNER = postgres
ENCODING = 'UTF8'
LC_COLLATE = 'Portuguese_Brazil.1252'
LC_CTYPE = 'Portuguese_Brazil.1252'
TABLESPACE = pg_default
CONNECTION LIMIT = -1;
	
	
-- Pessoa
Create Sequence sequence_pessoa Start 01 Increment 01;
Create Table pessoa
(
	idpessoa		Int8			Not Null	Default NextVal('sequence_pessoa'),
	flnatureza		Int2			Not Null,
	dsdocumento		VarChar(20)		Not Null,
	nmprimeiro		VarChar(100)	Not Null,
	nmsegundo		VarChar(100)	Not Null,
	dtregistro		Date			Null,
	
	Constraint pessoa_pk Primary Key (idpessoa)
);



-- Endereco
Create Sequence sequence_endereco Start 01 Increment 01;
Create Table endereco
(
	idendereco		Int8			Not Null	Default NextVal('sequence_endereco'),
	idpessoa		Int8			Not Null,
	dscep			VarChar(15)		Null,
	
	Constraint endereco_pk Primary Key (idendereco),
	Constraint endereco_fk_pessoa Foreign Key (idpessoa) References pessoa (idpessoa) On Delete Cascade
);
Create Index endereco_idpessoa On endereco (idpessoa);



-- Endereco - Integra��o
Create Table endereco_integracao
(
	idendereco		BigInt			Not Null,
	dsuf			VarChar(50)		Null,
	nmcidade		VarChar(100)	Null,
	nmbairro		VarChar(50)		Null,
	nmlogradouro	VarChar(100)	Null,
	dscomplemento	VarChar(100)	Null,
	
	Constraint enderecointegracao_pk Primary Key (idendereco),
	Constraint enderecointegracao_fk_endereco Foreign Key (idendereco) References endereco (idendereco) On Delete Cascade
);


http://localhost:8080/datasnap/rest/TServerMethods1
{
	{
		'ID':1,
		'campo1':'leandro',
		'campo2':'melo'
	}
}